	Unauthorized redistribution of this software is strictly prohibited.

	This software may only be distributed from the official release source.
	Re-uploading, mirroring, or sharing modified versions is strictly prohibited.

	Any unauthorized re-upload, mirror distribution, or modified redistribution - including uploads to file-sharing sites, repositories, or third-party platforms - is strictly prohibited.
	Only the official distribution source is authorized.


	NOTICE / IMPORTANT

	KOALA Downloader (BAT Edition)

	Please read this notice carefully before using this software.
	By using this software, you are deemed to have agreed to all terms below.

	1. Purpose of This Tool

	KOALA Downloader is a personal, non-commercial support tool for:

	MMD creation

	Video editing

	Personal content creation

	This software is NOT intended for piracy, redistribution, or abusive use.


	2. User Responsibility (IMPORTANT)

	All use of this software is entirely at your own risk.

	The author is NOT responsible for any of the following:

	Violation of laws or regulations

	Copyright infringement

	Account suspension or termination

	Data loss or system damage

	Legal claims from third parties

	Any direct or indirect damages

	If you do not understand or accept this, do not use this software.


	3. Copyright & Content Rights

	All videos, audio, and materials downloaded using this tool remain the property of their respective copyright holders.

	The following actions are strictly prohibited:

	Downloading copyrighted content without permission

	Re-uploading or redistributing downloaded content

	Public sharing without rights

	Commercial use of downloaded materials

	This includes content from platforms such as:

	- YouTube

	- Niconico Video

	4. Commercial Use Prohibited

	Commercial use of this software is strictly prohibited.

	This includes (but is not limited to):

	- Business use

	- Monetized content production

	- Paid services or commissions

	- Corporate or organizational use

	This tool is for personal, hobbyist use only.

	5. Redistribution & Modification

	You are NOT allowed to:

	- Redistribute this software

	- Modify and redistribute

	- Sell or repackage it

	- Upload it to other websites

	Unless explicit permission is granted by the author.

	6. Login & Cookie Usage

	This software may use browser cookies to access login-restricted content.

	Please note:

	- Cookies may contain personal account data

	- Sharing cookies with others is prohibited

	- Use on shared or public computers is at your own risk

	The author is not responsible for account-related issues.

	7. No Warranty

	This software is provided “AS IS”, without any warranty.

	The author does not guarantee:

	- Continuous operation

	- Compatibility with future platform changes

	- Error-free behavior

	- Fitness for any specific purpose

	8. Legal Compliance

	Users must comply with:

	- Local laws and regulations

	- International copyright laws

	- Platform terms of service

	- Public order and morals

	Any misuse is the sole responsibility of the user.

	9. Final Notice

	This software is created to support creators, not to harm them.

	If you use this tool for illegal, abusive, or unethical purposes,
	do not use this software.

	Respect creators.
	Respect the law.
	Use responsibly.

	Version
	KOALA Downloader
	NOTICE_EN
	2026